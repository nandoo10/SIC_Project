# UUIDs partilhados entre o Node (Servidor) e o Sink (Cliente)
CHAT_SERVICE_UUID = "12345678-1234-5678-1234-56789abcdef0"
CHAT_MSG_UUID     = "12345678-1234-5678-1234-56789abcdef1"